sudo apt-add-repository main -yy

sudo apt-add-repository restricted -yy

sudo apt-add-repository universe -yy

sudo apt-add-repository multiverse -yy

sudo apt update -yy

sudo apt upgrade -yy

sudo apt install lightdm-gtk-greeter lightdm-gtk-greeter-settings -yy

sudo apt install ubuntu-unity-desktop unity-tweak-tool -yy

sudo systemctl enable lightdm

