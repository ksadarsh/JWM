#!/bin/sh

####################################
#	Image Software
####################################

sudo apt install gimp -yy

sudo apt install inkscape -yy

