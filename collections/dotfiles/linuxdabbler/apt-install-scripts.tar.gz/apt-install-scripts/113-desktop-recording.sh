#!/bin/bash

#####################################
#	Desktop Recording
######################################

sudo apt install simplescreenrecorder -yy

sudo apt install obs-studio -yy
