#!/bin/sh


####################################
#	Email
####################################

sudo apt install thunderbird -yy

sudo apt install neomutt -yy

