#!/bin/sh

####################################
#	Sound Stuff
####################################

sudo apt install pavucontrol -yy

sudo apt install pulseaudio -yy

sudo apt install pulseaudio-utils  -yy

sudo apt install apulse -yy

sudo apt install pulseaudio-dlna  -yy

sudo apt install pulseaudio-equalizer -yy

sudo apt install gstreamer1.0-pulseaudio -yy

sudo apt install alsa-base -yy

sudo apt install alsa-utils -yy

sudo apt install gstreamer1.0-alsa -yy

sudo apt install libao-common -yy

sudo apt install libao-dbg -yy

sudo apt install libao-dev -yy

sudo apt intstall libao4 -yy

sudo apt install libasound2 -yy

sudo apt install libasound2-data  -yy

sudo apt install libasound-dev -yy

sudo apt install libasound-doc -yy

sudo apt install libasound-plugins -yy 

sudo apt install linux-sound-base -yy

sudo apt install alsaplayer-gtk -yy

sudo apt install alsaplayer-common -yy

sudo apt install alsaplayer-alsa -yy

sudo apt install alsaplayer-daemon -yy

sudo apt install alsamixergui -yy

sudo apt install volumeicon-alsa -yy

sudo apt install ubuntu-restricted-extras -yy

sudo apt install exfat-utils -yy








