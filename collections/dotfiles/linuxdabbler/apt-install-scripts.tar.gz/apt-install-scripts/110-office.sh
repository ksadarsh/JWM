#!/bin/sh

####################################
#	Office Software
####################################

sudo apt install libreoffice -yy
