#!/bin/sh

####################################
#	Web Browsers
####################################

# Install firefox
sudo apt install firefox -yy

# Install chromium
sudo apt install chromium-browser -yy
sudo apt install chromium-chromedriver -yy


