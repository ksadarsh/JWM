#!/bin/sh

sudo apt install k3b

sudo apt install asunder

sudo chmod 4711 /usr/bin/cdrdao

sudo chmod 4711 /usr/bin/wodim

