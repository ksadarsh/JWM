#!/bin/sh

wget https://downloads.vivaldi.com/stable/vivaldi-stable_2.1.1337.47-1_amd64.deb

sudo dpkg -i vivaldi*.deb


