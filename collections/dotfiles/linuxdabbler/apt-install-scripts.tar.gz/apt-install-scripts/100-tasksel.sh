#!/bin/sh

sudo apt install tasksel tasksel-data astro-tasks blends-tasks debichem-tasks electronics-tasks games-tasks gis-tasks hamradio-tasks junior-tasks med-tasks multimedia-tasks science-tasks

