#!/bin/sh

sudo apt install android-sdk adb android-sdk-build-tools android-sdk-common android-sdk-platform-tools -yy

