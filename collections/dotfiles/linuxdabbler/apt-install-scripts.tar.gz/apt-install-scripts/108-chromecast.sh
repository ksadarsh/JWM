#!/bin/sh

##############################################
#	Chromecast Stuff
##############################################

sudo apt install mkchromecast -yy

sudo apt install mkchromecast-alsa -yy

sudo apt install mkchromecast-gstreamer -yy

sudo apt install mkchromecast-pulseaudio -yy

sudo apt install pulseaudio-dlna -yy

sudo apt install python-pychromecast -yy
