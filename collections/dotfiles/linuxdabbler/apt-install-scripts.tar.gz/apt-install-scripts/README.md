# apt-install-scripts
scripts to install useful software (for me) automatically after an ubuntu based installation

If you download this, please READ THROUGH all scripts before running them.  These are strictly for testing and 
I will not be held accountable for messing up your system.  

Thanks

LD
