#!/bin/sh

####################################
#	Downloaders & Stuff
####################################

sudo apt install transmission-gtk -yy

sudo apt install git -yy

sudo apt install wget -yy

sudo apt install gdebi -yy

sudo apt install python-pip -yy

sudo apt install python3-pip -yy






