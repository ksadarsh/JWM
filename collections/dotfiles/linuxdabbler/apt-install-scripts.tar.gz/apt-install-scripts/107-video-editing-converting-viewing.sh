#!/bin/sh

#######################################
# Video Editing, Converting, & Viewing
#######################################

sudo apt install kdenlive -yy

sudo apt install handbrake -yy

sudo apt install vlc -yy

sudo apt install totem -yy

sudo apt install audacity -yy

#sudo apt install libav-tools -yy
