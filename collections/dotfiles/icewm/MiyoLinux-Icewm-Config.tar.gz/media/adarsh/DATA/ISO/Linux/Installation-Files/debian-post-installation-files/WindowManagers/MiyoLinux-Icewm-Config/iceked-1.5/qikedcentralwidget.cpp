/***************************************************************************
                          qikedcentralwidget.cpp  -  description
                             -------------------
    begin                : Wed Aug 28 2002
    copyright            : (C) 2002 by Vadim A. Khohlov
    email                : xvadim@teko.kherson.ua
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your keyion) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <qlabel.h>
#include <qlayout.h>
#include <qlistview.h>
#include <qhbox.h>
#include <qvbox.h>
#include <qcheckbox.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qmessagebox.h>

#include <qfile.h>
#include <qdir.h>
#include <qtextstream.h>

#include <qfiledialog.h>
#include <stdlib.h>

#include "iceked.h"
#include "qikedcentralwidget.h"

QString sCtrl("Ctrl");
QString sAlt("Alt");
QString sShift("Shift");

QIKedCentralWidget::QIKedCentralWidget(QWidget *parent, const char *name ):
QWidget(parent,name),
execPath("/usr/bin"),
isDirty(false)
{

	QVBoxLayout *topLayout = new QVBoxLayout(this, 0);
	CHECK_PTR(topLayout);

	lvKeys = new QListView(this);
	CHECK_PTR(lvKeys);
	lvKeys->addColumn(tr("Keys"));
	lvKeys->addColumn(tr("Command"));
	topLayout->addWidget(lvKeys);
	connect(lvKeys, SIGNAL(selectionChanged(QListViewItem*)), 
			SLOT(slotKeysSelectionChanged(QListViewItem*)));

	QLabel *lb = new QLabel(tr(" &Key:"), this);
	CHECK_PTR(lb);
	topLayout->addWidget(lb);
	
	QHBox *hb = new QHBox(this);
	CHECK_PTR(hb);
	topLayout->addWidget(hb);

	cbCtrl  = new QCheckBox("&Ctrl", hb);
	CHECK_PTR(cbCtrl);
	cbAlt   = new QCheckBox("&Alt", hb);
	CHECK_PTR(cbAlt);
	cbShift = new QCheckBox("&Shift", hb);
	CHECK_PTR(cbShift);
	edKeys  = new QLineEdit(hb);
	CHECK_PTR(edKeys);
	lb->setBuddy(edKeys);

	
	hb = new QHBox(this);
	CHECK_PTR(hb);
	topLayout->addWidget(hb);

	lb = new QLabel(tr(" &Program:"), hb);
	CHECK_PTR(lb);
	edProg = new QLineEdit(hb);
	CHECK_PTR(edProg);
	lb->setBuddy(edProg);

	QPushButton *pb = new QPushButton(tr("&Browse"), hb);
	CHECK_PTR(pb);
	connect(pb, SIGNAL(clicked()), SLOT(slotBrowse()));
	
	hb = new QHBox(this);
	CHECK_PTR(hb);
	topLayout->addWidget(hb);

	pb = new QPushButton(tr("S&et"), hb);
	CHECK_PTR(pb);
	connect(pb, SIGNAL(clicked()), SLOT(slotSet()));
	pb = new QPushButton(tr("A&dd"), hb);
	CHECK_PTR(pb);
	connect(pb, SIGNAL(clicked()), SLOT(slotAdd()));
	pbDel = new QPushButton(tr("De&l"), hb);
	CHECK_PTR(pbDel);
	connect(pbDel, SIGNAL(clicked()), SLOT(slotDel()));
	pbDel->setEnabled(false);

}/*constructor*/


QIKedCentralWidget::~QIKedCentralWidget()
{
}/* destructor*/

void QIKedCentralWidget::slotSet()
{
	QString keyStr;
	if(cbCtrl->isChecked())
		keyStr += sCtrl + '+';
	if(cbAlt->isChecked())
		keyStr += sAlt + '+';
	if(cbShift->isChecked())
		keyStr += sShift + '+';
	keyStr += edKeys->text();
	QListViewItem *it = lvKeys->currentItem();
	it->setText(0, keyStr);
	it->setText(1, edProg->text());
	if(!isDirty)
	{
		isDirty = true;
		((IceKedApp*)parentWidget())->contentChanged();
	} /* 	if(!isDirty) */
} /* void QIKedCentralWidget::slotSet() */

void QIKedCentralWidget::slotAdd()
{
	QListViewItem *it = new QListViewItem(lvKeys, "new keys", "new prog");
	lvKeys->setSelected(it, true);
	lvKeys->ensureItemVisible(it);
} /* void QIKedCentralWidget::slotAdd() */

void QIKedCentralWidget::slotDel()
{
	delete lvKeys->currentItem();
   	if(!isDirty)
	{
		isDirty = true;
		((IceKedApp*)parentWidget())->contentChanged();
	} /* 	if(!isDirty) */

} /* void QIKedCentralWidget::slotDel() */

void QIKedCentralWidget::loadKeys(const QString &fileName)
{
	QFile keyFile(fileName);
	QString s;
	QString keyStr;
	QString progStr;
	int     p1, p2, nStr;
	
	if(keyFile.open(IO_ReadOnly))
	{
		lvKeys->clear();
		QTextStream keyStream(&keyFile);
		nStr = 0;
		while((s = keyStream.readLine()) != QString::null)
		{
			nStr++;
			s = s.stripWhiteSpace();
			if(s.isEmpty() || s[0] == '#')   
				continue;
			if(s[0] != 'k' || s[1] != 'e' || s[2] != 'y')
			{
				QMessageBox::warning(this, tr("Error"),
						tr("Syntax error near line ") + keyStr.setNum(nStr) +
						tr(".\nKeyword \'key\' is absent"));
				continue;
			} /* 	if(s[0] != 'k' || s[1] != 'e' || s[2] != 'y') */
			p1 = s.find('\"');
			p2 = s.find('\"', p1 + 1);
			if(p1 == -1 || p2 == -1)
			{
				QMessageBox::warning(this, tr("Error"),
						tr("Syntax error near line ") + keyStr.setNum(nStr) +
						tr(".\n\" is absent"));
				continue;
			} /* if(p1 == -1 || p2 == -1) */
			keyStr  = s.mid(p1 + 1, p2 - p1 - 1).stripWhiteSpace();
			progStr = s.mid(p2 + 1).stripWhiteSpace();
			new QListViewItem(lvKeys, keyStr, progStr);
		} /*while((keyStr = keyStream.readLine()) != QString::null) */
		if(lvKeys->childCount())
		{
			pbDel->setEnabled(true);
			lvKeys->setSelected(lvKeys->firstChild(), true);
		} /* 		if(lvKeys->childCount()) */
		keyFile.close();
		isDirty = false;
	} /* 	if(keyFile.open(IO_ReadOnly)) */
	else
		QMessageBox::warning(this, tr("Error"),	tr("Can't open file ") + fileName);
} /* void QIKedCentralWidget::loadKeys(const QString &fileName) */

void QIKedCentralWidget::saveKeys(const QString &fileName)
{
	QString bakFileName(fileName);
	bakFileName += ".bak";
	QDir d;
	//std::rename(QFile::encodeName(fileName), QFile::encodeName(bakFileName));
	d.rename(fileName, bakFileName);
	
	QFile keyFile(fileName);
	
	if(!keyFile.open(IO_WriteOnly))
		QMessageBox::warning(this, tr("Error"),	tr("Can't open file ") + fileName);
	else
	{
		QTextStream keyStream(&keyFile);
		for(QListViewItem *it = lvKeys->firstChild(); 
						   it; it = it->nextSibling())
			keyStream << "key \"" << it->text(0) << "\" " <<
			   		     it->text(1) << '\n';
		keyFile.close();
		isDirty = false;
	} /* else if(!keyFile.open(IO_WriteOnly)) */
} /* void QIKedCentralWidget::saveKeys(const QString &fileName) */

/**
 * Browse programname.
 */
void QIKedCentralWidget::slotBrowse()
{
	const static QString path(getenv("PATH"));
	
	QString progName = QFileDialog::getOpenFileName(execPath, 0, this);
	if (!progName.isEmpty())
	{
		//remove dir from path if it possible
		QFileInfo fi(progName);
		execPath = fi.dirPath(true);
		if(path.find(execPath) != -1)
			edProg->setText(fi.fileName());
		else
			edProg->setText(progName);
	} /* 	if (!progName.isEmpty()) */
} /*   void slotBrowse() */

void QIKedCentralWidget::slotKeysSelectionChanged(QListViewItem *it)
{
	int pos;
	QString keyStr(it->text(0));

	pos = keyStr.findRev('+') + 1;
	edKeys->setText(keyStr.mid(pos));
	cbCtrl->setChecked(keyStr.find(sCtrl) + 1);
	cbAlt->setChecked(keyStr.find(sAlt) + 1);
	cbShift->setChecked(keyStr.find(sShift) + 1);
	edProg->setText(it->text(1));
} /* void QIKedCentralWidget::slotKeysSelectionChanged(QListViewItem *it) */
