/***************************************************************************
                          main.cpp  -  description
                             -------------------
    begin                : ��� ��� 28 17:58:20 EEST 2002
    copyright            : (C) 2002 by Vadim A. Khohlov
    email                : xvadim@teko.kherson.ua
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <qapplication.h>
#include <qfont.h>
#include <qstring.h>
#include <qtextcodec.h>
#include <qtranslator.h>

#include "iceked.h"

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  //a.setFont(QFont("helvetica", 12));
  QTranslator tor( 0 );
  tor.load( QString("iceked_") + QTextCodec::locale(), PREFIX"/share/iceked/locale");
  a.installTranslator( &tor );
  /* uncomment the following line, if you want a Windows 95 look*/
  // a.setStyle(WindowsStyle);
    
  IceKedApp *iceked=new IceKedApp();
  a.setMainWidget(iceked);

  iceked->show();

  return a.exec();
}


