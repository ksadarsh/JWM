/***************************************************************************
                          qikedcentralwidget.h  -  description
                             -------------------
    begin                : Wed Aug 28 2002
    copyright            : (C) 2002 by Vadim A. Khohlov
    email                : xvadim@teko.kherson.ua
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef QIKEDCENTRALWIDGET_H
#define QIKEDCENTRALWIDGET_H

#include <qwidget.h>

class QListView;
class QListViewItem;
class QCheckBox;
class QLineEdit;
class QPushButton;

/**
 * This is central widget with all controls.
 * @author Vadim A. Khohlov
 */

class QIKedCentralWidget : public QWidget  {
   Q_OBJECT
public: 
	QIKedCentralWidget(QWidget *parent=0, const char *name=0);
	~QIKedCentralWidget();
	
  	void saveKeys(const QString &fileName);
  	void loadKeys(const QString &fileName);
  	bool isKeysDirty();
private: // Private attributes
    /**
     * The list of keys.
     */
    QListView *lvKeys;
	QCheckBox *cbCtrl;
	QCheckBox *cbAlt;
	QCheckBox *cbShift;

	QLineEdit *edKeys;
	QLineEdit *edProg;

	QPushButton *pbDel;

	QString execPath;
   
	/**
    * a dirty flag - true if menu changed.
    */
    bool isDirty;
	
private: // Private methods

private slots: // Private slots
  void slotDel();
  void slotAdd();
  void slotSet();
  /**
   * Browse programname.
   */
  void slotBrowse();
  /** No descriptions */
  void slotKeysSelectionChanged(QListViewItem *it);
};

inline
bool QIKedCentralWidget::isKeysDirty()
{
    return isDirty;    
}/* isMenuDirty() */

#endif
