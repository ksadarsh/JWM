<!DOCTYPE TS><TS>
<context>
    <name>IceKedApp</name>
    <message>
        <source>Open File</source>
        <translation type="unfinished">Відкрити файл</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="unfinished">&amp;Відкрити...</translation>
    </message>
    <message>
        <source>Opens an existing document</source>
        <translation type="unfinished">Відкриває існуючий документ</translation>
    </message>
    <message>
        <source>Open File

Opens an existing document</source>
        <translation type="unfinished">Відкрити файл

Відкриває існуючий документ</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation type="unfinished">Зберігти файл</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished">&amp;Зберегти</translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saves the actual document</source>
        <translation type="unfinished">Зберегти поточний документ</translation>
    </message>
    <message>
        <source>Save File.

Saves the actual document</source>
        <translation type="unfinished">Зберегти файл

Зберігає поточний документ</translation>
    </message>
    <message>
        <source>Save File As</source>
        <translation type="unfinished">Зберегти як</translation>
    </message>
    <message>
        <source>Save &amp;as...</source>
        <translation type="unfinished">З&amp;берегти як</translation>
    </message>
    <message>
        <source>Saves the actual document under a new filename</source>
        <translation type="unfinished">Зберегти поточний документ на диск з новою назвою </translation>
    </message>
    <message>
        <source>Save As

Saves the actual document under a new filename</source>
        <translation type="unfinished">Зберегти як

Зберегти поточний документ на диск з новою назвою </translation>
    </message>
    <message>
        <source>Restart IceWM</source>
        <translation type="unfinished">Перезапустити IceWM</translation>
    </message>
    <message>
        <source>&amp;Restart IceWM</source>
        <translation type="unfinished">&amp;Перезапустити IceWM</translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restart the IceWM</source>
        <translation type="unfinished">Перезапустити IceWM</translation>
    </message>
    <message>
        <source>Restart

Restarts the IceWM</source>
        <translation type="unfinished">Перезапустити

Перезапустити IceMW</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="unfinished">Вихід</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished">&amp;Вихід</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quits the application</source>
        <translation type="unfinished">Завершити роботу програми</translation>
    </message>
    <message>
        <source>Exit

Quits the application</source>
        <translation type="unfinished">Вихід

Завершити роботу програми</translation>
    </message>
    <message>
        <source>Toolbar</source>
        <translation type="unfinished">Панель інструментів</translation>
    </message>
    <message>
        <source>Tool&amp;bar</source>
        <translation type="unfinished">&amp;Панель інструментів</translation>
    </message>
    <message>
        <source>Enables/disables the toolbar</source>
        <translation type="unfinished">Показує/ховає панель інструментів</translation>
    </message>
    <message>
        <source>Toolbar

Enables/disables the toolbar</source>
        <translation type="unfinished">Панель інструментів

Показує/ховає панель інструментів</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation type="unfinished">&amp;Рядок статусу</translation>
    </message>
    <message>
        <source>&amp;Statusbar</source>
        <translation type="unfinished">&amp;Рядок статусу</translation>
    </message>
    <message>
        <source>Enables/disables the statusbar</source>
        <translation type="unfinished">Показує/ховає рядок статусу</translation>
    </message>
    <message>
        <source>Statusbar

Enables/disables the statusbar</source>
        <translation type="unfinished">Рядок статусу

Показує/ховає рядок статусу</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished">Про програму</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="unfinished">&amp;Про програму</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation type="unfinished">Про програму</translation>
    </message>
    <message>
        <source>About

About the application</source>
        <translation type="unfinished">Про

Про програму</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished">&amp;Вигляд</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;Довідка</translation>
    </message>
    <message>
        <source>Ready.</source>
        <translation type="unfinished">Готовий.</translation>
    </message>
    <message>
        <source>Opening file...</source>
        <translation type="unfinished">Відкриття файлу</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation type="unfinished">Завантажено документ:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation type="unfinished">Відкриття припинене</translation>
    </message>
    <message>
        <source>Saving file...</source>
        <translation type="unfinished">Зберігання файлу</translation>
    </message>
    <message>
        <source>Saving file under new filename...</source>
        <translation type="unfinished">Зберігання файлу на диск з новою назвою</translation>
    </message>
    <message>
        <source>Saving aborted</source>
        <translation type="unfinished">Зберігання припинене</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation type="unfinished">Завершення робботи програми...</translation>
    </message>
    <message>
        <source>Toggle toolbar...</source>
        <translation type="unfinished">Показати/сховати панель інструментів...</translation>
    </message>
    <message>
        <source>Toggle statusbar...</source>
        <translation type="unfinished">Показати/сховати панель рядок статусу...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="unfinished">Про програму...</translation>
    </message>
    <message>
        <source>Attention!</source>
        <translation type="unfinished">Увага!</translation>
    </message>
    <message>
        <source>Content was changed.
Do you want to save it?</source>
        <translation type="unfinished">Зміст файлу було змінено.
Бажаєте зберігти зміни?</translation>
    </message>
</context>
<context>
    <name>QIKedCentralWidget</name>
    <message>
        <source>Keys</source>
        <translation type="unfinished">Клавіши</translation>
    </message>
    <message>
        <source>Command</source>
        <translation type="unfinished">Команда</translation>
    </message>
    <message>
        <source> &amp;Key:</source>
        <translation type="unfinished">&amp;Клавіша:</translation>
    </message>
    <message>
        <source> &amp;Program:</source>
        <translation type="unfinished">&amp;Програма:</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation type="unfinished">&amp;Перегляд...</translation>
    </message>
    <message>
        <source>S&amp;et</source>
        <translation type="unfinished">&amp;Встановити</translation>
    </message>
    <message>
        <source>A&amp;dd</source>
        <translation type="unfinished">&amp;Додати...</translation>
    </message>
    <message>
        <source>De&amp;l</source>
        <translation type="unfinished">&amp;Видалити</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Помилка</translation>
    </message>
    <message>
        <source>Syntax error near line </source>
        <translation type="unfinished">Помилка в синтаксисі біля рядка</translation>
    </message>
    <message>
        <source>.
Keyword &apos;key&apos; is absent</source>
        <translation type="unfinished">.
Відсутнє ключове слово  &apos;key&apos; </translation>
    </message>
    <message>
        <source>.
&quot; is absent</source>
        <translation type="unfinished">.
&quot; відсутнє</translation>
    </message>
    <message>
        <source>Can&apos;t open file </source>
        <translation type="unfinished">Неможливо відкрити</translation>
    </message>
</context>
</TS>
