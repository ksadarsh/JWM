/***************************************************************************
                          iceked.cpp  -  description
                             -------------------
    begin                : ��� ��� 28 17:58:20 EEST 2002
    copyright            : (C) 2002 by Vadim A. Khohlov
    email                : xvadim@teko.kherson.ua
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>

#include <qaccel.h>
#include <qwhatsthis.h>
#include <qmessagebox.h>
#include <qfiledialog.h>
#include <qdir.h>

#include "iceked.h"
#include "filesave.xpm"
#include "fileopen.xpm"
#include "exit.xpm"
#include "icewm.xpm"

#include "qikedcentralwidget.h"

IceKedApp::IceKedApp():
icewmCfgDir(getenv("ICEWM_PRIVCFG")),
programName(tr("Keys' editor for IceWM " VERSION))
{
  ///////////////////////////////////////////////////////////////////
  // call inits to invoke all other construction parts
  initActions();
  initMenuBar();
  initToolBar();
  initStatusBar();

  viewToolBar->setOn(true);
  viewStatusBar->setOn(true);

  centralWidget = new QIKedCentralWidget(this);
  setCentralWidget(centralWidget);

  if(icewmCfgDir.isNull())
    icewmCfgDir = QDir::homeDirPath() + "/.icewm";
  
  if(qApp->argc() > 1)
	keyFileName = qApp->argv()[1];
  else
    keyFileName = icewmCfgDir + "/keys";
  centralWidget->loadKeys(keyFileName);
  setCaption(keyFileName + " - " + programName);
  fileSave->setEnabled(false);
  fileSaveAs->setEnabled(false);
}

IceKedApp::~IceKedApp()
{
}

/** initializes all QActions of the application */
void IceKedApp::initActions(){

  QPixmap openIcon(fileopen), saveIcon(filesave);
  QPixmap exitIcon(exit_xpm), iceIcon(icewm);

  fileOpen = new QAction(tr("Open File"), openIcon, tr("&Open..."), 0, this);
  fileOpen->setStatusTip(tr("Opens an existing document"));
  fileOpen->setWhatsThis(tr("Open File\n\nOpens an existing document"));
  connect(fileOpen, SIGNAL(activated()), this, SLOT(slotFileOpen()));

  fileSave = new QAction(tr("Save File"), saveIcon,
		  tr("&Save"), QAccel::stringToKey(tr("Ctrl+S")), this);
  fileSave->setStatusTip(tr("Saves the actual document"));
  fileSave->setWhatsThis(tr("Save File.\n\nSaves the actual document"));
  connect(fileSave, SIGNAL(activated()), this, SLOT(slotFileSave()));

  fileSaveAs = new QAction(tr("Save File As"), tr("Save &as..."), 0, this);
  fileSaveAs->setStatusTip(tr("Saves the actual document under a new filename"));
  fileSaveAs->setWhatsThis(tr("Save As\n\nSaves the actual document under a new filename"));
  connect(fileSaveAs, SIGNAL(activated()), this, SLOT(slotFileSaveAs()));

  fileRestartIce = new QAction(tr("Restart IceWM"), iceIcon, 
		  tr("&Restart IceWM"), QAccel::stringToKey(tr("Ctrl+R")), this);
  fileRestartIce->setStatusTip(tr("Restart the IceWM"));
  fileRestartIce->setWhatsThis(tr("Restart\n\nRestarts the IceWM"));
  connect(fileRestartIce, SIGNAL(activated()), this, SLOT(slotRestartIcewm()));
  
  fileQuit = new QAction(tr("Exit"), exitIcon, tr("E&xit"),
		  QAccel::stringToKey(tr("Ctrl+Q")), this);
  fileQuit->setStatusTip(tr("Quits the application"));
  fileQuit->setWhatsThis(tr("Exit\n\nQuits the application"));
  connect(fileQuit, SIGNAL(activated()), this, SLOT(slotFileQuit()));

  viewToolBar = new QAction(tr("Toolbar"), tr("Tool&bar"), 0, this, 0, true);
  viewToolBar->setStatusTip(tr("Enables/disables the toolbar"));
  viewToolBar->setWhatsThis(tr("Toolbar\n\nEnables/disables the toolbar"));
  connect(viewToolBar, SIGNAL(toggled(bool)), this, SLOT(slotViewToolBar(bool)));

  viewStatusBar = new QAction(tr("Statusbar"), tr("&Statusbar"), 0, this, 0, true);
  viewStatusBar->setStatusTip(tr("Enables/disables the statusbar"));
  viewStatusBar->setWhatsThis(tr("Statusbar\n\nEnables/disables the statusbar"));
  connect(viewStatusBar, SIGNAL(toggled(bool)), this, SLOT(slotViewStatusBar(bool)));

  helpAboutApp = new QAction(tr("About"), tr("&About..."), 0, this);
  helpAboutApp->setStatusTip(tr("About the application"));
  helpAboutApp->setWhatsThis(tr("About\n\nAbout the application"));
  connect(helpAboutApp, SIGNAL(activated()), this, SLOT(slotHelpAbout()));

}

void IceKedApp::initMenuBar()
{
  ///////////////////////////////////////////////////////////////////
  // MENUBAR

  ///////////////////////////////////////////////////////////////////
  // menuBar entry fileMenu
  fileMenu=new QPopupMenu();
  fileOpen->addTo(fileMenu);
  fileMenu->insertSeparator();
  fileSave->addTo(fileMenu);
  fileSaveAs->addTo(fileMenu);
  fileMenu->insertSeparator();
  fileRestartIce->addTo(fileMenu);
  fileMenu->insertSeparator();
  fileQuit->addTo(fileMenu);

  ///////////////////////////////////////////////////////////////////
  // menuBar entry viewMenu
  viewMenu=new QPopupMenu();
  viewMenu->setCheckable(true);
  viewToolBar->addTo(viewMenu);
  viewStatusBar->addTo(viewMenu);
  ///////////////////////////////////////////////////////////////////
  // EDIT YOUR APPLICATION SPECIFIC MENUENTRIES HERE

  ///////////////////////////////////////////////////////////////////
  // menuBar entry helpMenu
  helpMenu=new QPopupMenu();
  helpAboutApp->addTo(helpMenu);

  ///////////////////////////////////////////////////////////////////
  // MENUBAR CONFIGURATION
  menuBar()->insertItem(tr("&File"), fileMenu);
  menuBar()->insertItem(tr("&View"), viewMenu);
  menuBar()->insertSeparator();
  menuBar()->insertItem(tr("&Help"), helpMenu);

}

void IceKedApp::initToolBar()
{
  ///////////////////////////////////////////////////////////////////
  // TOOLBAR
  fileToolbar = new QToolBar(this, "file operations");
  fileOpen->addTo(fileToolbar);
  fileSave->addTo(fileToolbar);
  fileToolbar->addSeparator();
  fileRestartIce->addTo(fileToolbar);
  fileToolbar->addSeparator();
  QWhatsThis::whatsThisButton(fileToolbar);
  fileToolbar->addSeparator();
  fileQuit->addTo(fileToolbar);
}

void IceKedApp::initStatusBar()
{
  ///////////////////////////////////////////////////////////////////
  //STATUSBAR
  statusBar()->message(tr("Ready."), 2000);
}

/////////////////////////////////////////////////////////////////////
// SLOT IMPLEMENTATION
/////////////////////////////////////////////////////////////////////


void IceKedApp::slotFileOpen()
{
  statusBar()->message(tr("Opening file..."));
  checkDirty();
  keyFileName = QFileDialog::getOpenFileName(icewmCfgDir, 0, this);
  if (!keyFileName.isEmpty())
  {
    QString message=tr("Loaded document: ")+keyFileName;
    centralWidget->loadKeys(keyFileName);
  	setCaption(keyFileName + " - " + programName);
  	fileSave->setEnabled(false);
  	fileSaveAs->setEnabled(false);
    statusBar()->message(message, 2000);
  }
  else
    statusBar()->message(tr("Opening aborted"), 2000);
}


void IceKedApp::slotFileSave()
{
	statusBar()->message(tr("Saving file..."));
	if(keyFileName.isEmpty())
		slotFileSaveAs();
	else
	{
		centralWidget->saveKeys(keyFileName);
  		setCaption(keyFileName + " - " + programName);
  		fileSave->setEnabled(false);
  		fileSaveAs->setEnabled(false);
	} /* 	else */
	statusBar()->message(tr("Ready."));
}

void IceKedApp::slotFileSaveAs()
{
	statusBar()->message(tr("Saving file under new filename..."));
	QString fn = QFileDialog::getSaveFileName(icewmCfgDir, 0, this);
	if (!fn.isEmpty())
	{
		keyFileName = fn;
		centralWidget->saveKeys(keyFileName);
  		setCaption(keyFileName + " - " + programName);
  		fileSave->setEnabled(false);
  		fileSaveAs->setEnabled(false);
	} /* 	if (!fn.isEmpty()) */
  else
    statusBar()->message(tr("Saving aborted"), 2000);

  statusBar()->message(tr("Ready."));
}

void IceKedApp::slotFileQuit()
{
  statusBar()->message(tr("Exiting application..."));
  checkDirty();
  qApp->quit();
  statusBar()->message(tr("Ready."));
}


void IceKedApp::slotViewToolBar(bool toggle)
{
  statusBar()->message(tr("Toggle toolbar..."));
  ///////////////////////////////////////////////////////////////////
  // turn Toolbar on or off

  if (toggle== false)
    fileToolbar->hide();
  else
    fileToolbar->show();

  statusBar()->message(tr("Ready."));
}

void IceKedApp::slotViewStatusBar(bool toggle)
{
  statusBar()->message(tr("Toggle statusbar..."));
  ///////////////////////////////////////////////////////////////////
  //turn Statusbar on or off

  if (toggle == false)
    statusBar()->hide();
  else
    statusBar()->show();

  statusBar()->message(tr("Ready."));
}

void IceKedApp::slotHelpAbout()
{
  QMessageBox::about(this,tr("About..."),
                tr("Keys' editor for IceWM\nVersion " VERSION 
				   "\n(c) 2002-2004 by Vadim A. Khohlov") );
} /* void IceKedApp::slotHelpAbout() */

/** No descriptions */
void IceKedApp::slotRestartIcewm()
{
	system("killall -HUP icewm");
} /* void IcemcApp::slotRestartIcewm() */

/**
* Called by centralwidget after changing the content.
* Add '*' into caption.
*/
void
IceKedApp::contentChanged()
{
	setCaption(keyFileName + " [*] - " + programName);
	fileSave->setEnabled(true);
	fileSaveAs->setEnabled(true);
} /* IcemcApp ::contentChanged() */

/**
* Checks dirty flag of centralwidget and saves menu if necessary.
*/
void
IceKedApp::checkDirty()
{
	if(centralWidget->isKeysDirty())
		if(QMessageBox::warning(this, tr("Attention!"),
					tr("Content was changed.\nDo you want to save it?"),
					QMessageBox::Yes, QMessageBox::No) == QMessageBox::Yes)
			slotFileSave();
} /* IcemcApp ::checkDirty() */
