X.Template es una tipografía Stencil, negra y condensada, con serifas cuadradas de acabado redondeado. Una virguería para diseño de carteles y posters.

Italic version available in my web http://www.defharo.com

Thank you for your interest in my font :) This font is free for personal use only. If you are interested in commercial use, you can buy the license in http://defharo.com/tipografia/x-template-stencil-font/ 

You may redistribute my fonts on your site as long as credit is http://defharo.com as the original author.Donations are always welcome :)
